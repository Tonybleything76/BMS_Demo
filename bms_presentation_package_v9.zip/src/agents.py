from typing import Dict, Any, List, Tuple, Optional
import re
import json
import os
from datetime import datetime
import autogen
from autogen import Agent, AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Get the API key from environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Check if API key is loaded
if not OPENAI_API_KEY:
    print("ERROR: OPENAI_API_KEY environment variable not found.")
    print("Please ensure you have a .env file with OPENAI_API_KEY=your_key_here")
else:
    print("DEBUG - OpenAI API Key loaded successfully.")

# Define the BuildingChangeTracker class to track changes
class BuildingChangeTracker:
    def __init__(self):
        self.changes = []
        self.next_id = 1
        # Add hardcoded changes for demonstration
        self._add_hardcoded_changes()
    
    def _add_hardcoded_changes(self):
        """Add hardcoded changes for demonstration purposes."""
        print("DEBUG - Adding hardcoded changes for demonstration")
        
        # Hardcoded change 1
        self.add_change(
            agent="energy_optimization_agent",
            system="HVAC",
            action="Adjust zone temperature setpoints to optimize energy usage",
            reason="Current settings show potential inefficiencies in temperature distribution",
            status="verified"
        )
        
        # Hardcoded change 2
        self.add_change(
            agent="energy_optimization_agent",
            system="Lighting",
            action="Implement daylight harvesting in perimeter zones",
            reason="Natural light is underutilized, leading to excess energy consumption",
            status="verified"
        )
        
        # Hardcoded change 3
        self.add_change(
            agent="predictive_maintenance_agent",
            system="Chiller",
            action="Schedule immediate inspection of bearing assembly",
            reason="Vibration analysis indicates early signs of bearing wear",
            status="verified"
        )
        
        # Hardcoded change 4
        self.add_change(
            agent="predictive_maintenance_agent",
            system="Air Handling Unit",
            action="Replace filter media and clean coils",
            reason="Pressure differential indicates restricted airflow",
            status="verified"
        )
        
        # Hardcoded change 5
        self.add_change(
            agent="safety_compliance_agent",
            system="Emergency Lighting",
            action="Replace failed backup batteries in east wing",
            reason="Monthly test showed insufficient emergency runtime",
            status="verified"
        )
        
        # Hardcoded change 6
        self.add_change(
            agent="safety_compliance_agent",
            system="CO2 Monitoring",
            action="Recalibrate sensors in conference rooms",
            reason="Readings show inconsistent values compared to portable verification equipment",
            status="verified"
        )
        
        # Hardcoded change 7 - one rejected for demonstration
        self.add_change(
            agent="energy_optimization_agent",
            system="Solar Panel Array",
            action="Increase panel tilt angle by 15 degrees",
            reason="Might improve winter performance",
            status="rejected"
        )
        
        print(f"DEBUG - Added {len(self.changes)} hardcoded changes")
    
    def add_change(self, agent: str, system: str, action: str, reason: str, status: str = "pending") -> int:
        """Add a new change to the tracker."""
        print(f"DEBUG - Adding change: agent={agent}, system={system}, action={action}, status={status}")
        change_id = self.next_id
        self.next_id += 1
        
        self.changes.append({
            "id": change_id,
            "agent": agent,
            "system": system,
            "action": action,
            "reason": reason,
            "status": status,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        return change_id
    
    def update_change_status(self, change_id: int, status: str, reason: str = "") -> bool:
        """Update the status of a change."""
        print(f"DEBUG - Updating change status: id={change_id}, status={status}")
        for change in self.changes:
            if change["id"] == change_id:
                change["status"] = status
                if reason:
                    change["review_reason"] = reason
                return True
        return False
    
    def get_all_changes(self) -> List[Dict[str, Any]]:
        """Get all changes."""
        print(f"DEBUG - Getting all changes: {len(self.changes)} changes found")
        return self.changes
    
    def get_pending_changes(self) -> List[Dict[str, Any]]:
        """Get all pending changes."""
        pending = [c for c in self.changes if c["status"] == "pending"]
        print(f"DEBUG - Getting pending changes: {len(pending)} found")
        return pending
    
    def get_verified_changes(self) -> List[Dict[str, Any]]:
        """Get all verified changes."""
        verified = [c for c in self.changes if c["status"] == "verified"]
        print(f"DEBUG - Getting verified changes: {len(verified)} found")
        return verified
    
    def get_rejected_changes(self) -> List[Dict[str, Any]]:
        """Get all rejected changes."""
        rejected = [c for c in self.changes if c["status"] == "rejected"]
        print(f"DEBUG - Getting rejected changes: {len(rejected)} found")
        return rejected

# Function to extract change proposals from agent messages
def extract_change_proposal(message: str, change_tracker: BuildingChangeTracker) -> None:
    """Extract change proposals from agent message."""
    print(f"DEBUG - Attempting to extract change proposal from message")
    print(f"DEBUG - Message excerpt: {message[:200]}...")
    
    # Look for CHANGE PROPOSAL format
    pattern = r"CHANGE PROPOSAL:\s*\n.*?System:\s*(.*?)[\r\n]+Action:\s*(.*?)[\r\n]+Reason:\s*(.*?)[\r\n]+"
    matches = re.finditer(pattern, message, re.DOTALL | re.IGNORECASE)
    
    found = False
    for match in matches:
        found = True
        system = match.group(1).strip()
        action = match.group(2).strip()
        reason = match.group(3).strip()
        print(f"DEBUG - Extracted change proposal: system={system}, action={action}")
        change_tracker.add_change("building_systems_agent", system, action, reason)
    
    # If no matches with the standard format, try alternative formats
    if not found:
        # Alternative format - look for specific sections in the message
        alt_system_pattern = r"System:\s*([^\n]+)"
        alt_action_pattern = r"Action:\s*([^\n]+)"
        alt_reason_pattern = r"Reason:\s*([^\n]+)"
        
        system_matches = re.finditer(alt_system_pattern, message, re.IGNORECASE)
        action_matches = re.finditer(alt_action_pattern, message, re.IGNORECASE)
        reason_matches = re.finditer(alt_reason_pattern, message, re.IGNORECASE)
        
        systems = [m.group(1).strip() for m in system_matches]
        actions = [m.group(1).strip() for m in action_matches]
        reasons = [m.group(1).strip() for m in reason_matches]
        
        # If we have equal numbers of each, assume they match up
        if len(systems) == len(actions) == len(reasons) and len(systems) > 0:
            for i in range(len(systems)):
                print(f"DEBUG - Extracted change proposal (alt format): system={systems[i]}, action={actions[i]}")
                change_tracker.add_change("building_systems_agent", systems[i], actions[i], reasons[i])
                found = True
    
    if not found:
        print("DEBUG - No change proposal found in message")

# Function to extract change reviews from agent messages
def extract_change_review(message: str, change_tracker: BuildingChangeTracker) -> None:
    """Extract change reviews from agent message."""
    print(f"DEBUG - Attempting to extract change review from message")
    print(f"DEBUG - Message excerpt: {message[:200]}...")
    
    # Look for CHANGE REVIEW format
    pattern = r"CHANGE REVIEW:\s*\n.*?Change ID:\s*(\d+).*?Status:\s*(verified|rejected)"
    matches = re.finditer(pattern, message, re.DOTALL | re.IGNORECASE)
    
    found = False
    for match in matches:
        found = True
        change_id = int(match.group(1))
        status = match.group(2).lower()
        print(f"DEBUG - Extracted change review: id={change_id}, status={status}")
        change_tracker.update_change_status(change_id, status)
    
    # If no formal reviews found, try more flexible patterns
    if not found:
        # Look for mentions of specific change IDs with approval/rejection language
        id_pattern = r"(?:change|proposal|recommendation)(?:\s+|\s+id\s+|\s+#\s*)(\d+)(?:\s+is\s+|\s+has\s+been\s+|\s+will\s+be\s+)?(?:approved|verified|accepted|rejected|denied)"
        id_matches = re.finditer(id_pattern, message.lower(), re.IGNORECASE)
        
        for match in id_matches:
            found = True
            change_id = int(match.group(1))
            if "approved" in message.lower() or "verified" in message.lower() or "accepted" in message.lower():
                status = "verified"
            else:
                status = "rejected"
            print(f"DEBUG - Extracted change review (flexible pattern): id={change_id}, status={status}")
            change_tracker.update_change_status(change_id, status)
    
    # If still no reviews found, check for blanket approval/rejection statements
    if not found:
        # Check for statements about approving/rejecting all changes
        if re.search(r"(?:approve|verify|accept)(?:\s+all|\s+each|\s+every)\s+(?:change|proposal|recommendation)", message.lower()):
            print(f"DEBUG - Found blanket approval statement")
            for change in change_tracker.get_pending_changes():
                change_tracker.update_change_status(change["id"], "verified")
            found = True
        
        elif re.search(r"(?:reject|deny)(?:\s+all|\s+each|\s+every)\s+(?:change|proposal|recommendation)", message.lower()):
            print(f"DEBUG - Found blanket rejection statement")
            for change in change_tracker.get_pending_changes():
                change_tracker.update_change_status(change["id"], "rejected")
            found = True
        
        # Check for simpler approval/rejection keywords as a last resort
        elif "approved" in message.lower() or "approve" in message.lower() or "accept" in message.lower():
            print(f"DEBUG - Found approval keyword")
            for change in change_tracker.get_pending_changes():
                change_tracker.update_change_status(change["id"], "verified")
            found = True
        
        elif "rejected" in message.lower() or "reject" in message.lower() or "deny" in message.lower():
            print(f"DEBUG - Found rejection keyword")
            for change in change_tracker.get_pending_changes():
                change_tracker.update_change_status(change["id"], "rejected")
            found = True
    
    if not found:
        print("DEBUG - No change review found in message")

# Define the agent system prompts
DATA_INTEGRATION_SYSTEM_PROMPT = """
You are the Data Integration Agent (Nexus), the central coordinator for the Building Management Multi-Agent System.

Your responsibilities include:
1. Analyzing building data to identify issues requiring attention
2. Coordinating with specialized agents to address specific domains
3. Reviewing and approving/rejecting change proposals from specialized agents
4. Synthesizing approved changes into a coherent action plan
5. Generating a final report with recommendations

When specialized agents propose changes, review them carefully and either approve or reject them.
For each change proposal, respond with a CHANGE REVIEW in this format:

CHANGE REVIEW:
Change ID: [ID number]
Status: [verified/rejected]
Reason: [Brief explanation of your decision]

After reviewing all changes, synthesize the approved changes into a coherent action plan and final report.
"""

ENERGY_OPTIMIZATION_SYSTEM_PROMPT = """
You are the Energy Optimization Agent (Thermosynergix), specializing in HVAC systems and energy usage.

Your responsibilities include:
1. Analyzing HVAC system performance and capacity
2. Identifying energy inefficiencies and optimization opportunities
3. Recommending load redistribution during peak demand
4. Suggesting energy-saving measures
5. Coordinating with renewable energy sources

When you identify an issue or optimization opportunity, propose a specific change using this format:

CHANGE PROPOSAL:
System: [Name of the system to be modified]
Action: [Specific action to take]
Reason: [Justification for the change]
Expected Outcome: [What will improve after the change]
"""

PREDICTIVE_MAINTENANCE_SYSTEM_PROMPT = """
You are the Predictive Maintenance Agent (Prognosticator), specializing in equipment health and maintenance.

Your responsibilities include:
1. Monitoring equipment performance metrics
2. Identifying potential failures before they occur
3. Recommending preventive maintenance actions
4. Optimizing maintenance schedules
5. Extending equipment lifespan

When you identify a maintenance issue or optimization opportunity, propose a specific change using this format:

CHANGE PROPOSAL:
System: [Name of the system to be modified]
Action: [Specific action to take]
Reason: [Justification for the change]
Expected Outcome: [What will improve after the change]
"""

SAFETY_COMPLIANCE_SYSTEM_PROMPT = """
You are the Safety Compliance Agent (Vigilance), specializing in building safety and regulatory compliance.

Your responsibilities include:
1. Monitoring safety systems and environmental conditions
2. Ensuring compliance with safety regulations
3. Identifying potential safety hazards
4. Recommending corrective actions for safety issues
5. Prioritizing occupant well-being

When you identify a safety issue or compliance concern, propose a specific change using this format:

CHANGE PROPOSAL:
System: [Name of the system to be modified]
Action: [Specific action to take]
Reason: [Justification for the change]
Expected Outcome: [What will improve after the change]
"""

USER_PROXY_SYSTEM_PROMPT = """
You are the Building Manager, overseeing the Building Management Multi-Agent System.

Your role is to:
1. Provide building data to the agent system
2. Observe the analysis and recommendations
3. Review the final action plan
4. Implement approved changes

The specialized agents will analyze the data and propose changes, which will be reviewed by the Data Integration Agent.
"""

def initialize_agents(verbose=False) -> Tuple[Agent, Agent, BuildingChangeTracker, GroupChat]:
    """Initialize the agents for the Building Management Multi-Agent System."""
    # Create a change tracker
    change_tracker = BuildingChangeTracker()
    
    # Define the LLM config with the explicitly loaded API key
    llm_config = {
        "config_list": [{
            "model": "gpt-3.5-turbo",
            "api_key": OPENAI_API_KEY  # Pass the key directly
        }]
    }
    
    # Create the agents
    data_integration_agent = AssistantAgent(
        name="data_integration_agent",
        system_message=DATA_INTEGRATION_SYSTEM_PROMPT,
        llm_config=llm_config,
    )
    
    energy_optimization_agent = AssistantAgent(
        name="energy_optimization_agent",
        system_message=ENERGY_OPTIMIZATION_SYSTEM_PROMPT,
        llm_config=llm_config,
    )
    
    predictive_maintenance_agent = AssistantAgent(
        name="predictive_maintenance_agent",
        system_message=PREDICTIVE_MAINTENANCE_SYSTEM_PROMPT,
        llm_config=llm_config,
    )
    
    safety_compliance_agent = AssistantAgent(
        name="safety_compliance_agent",
        system_message=SAFETY_COMPLIANCE_SYSTEM_PROMPT,
        llm_config=llm_config,
    )
    
    # Create a user proxy agent to represent the building manager
    user_proxy = UserProxyAgent(
        name="user_proxy",
        system_message=USER_PROXY_SYSTEM_PROMPT,
        human_input_mode="NEVER",
        max_consecutive_auto_reply=0,
        code_execution_config=False,
    )
    
    # Create a group chat
    groupchat = GroupChat(
        agents=[user_proxy, data_integration_agent, energy_optimization_agent, predictive_maintenance_agent, safety_compliance_agent],
        messages=[],
        max_round=12,
    )
    
    # Create a group chat manager
    manager = GroupChatManager(groupchat=groupchat, llm_config=llm_config)
    
    return user_proxy, manager, change_tracker, groupchat

def run_scenario(user_proxy: Agent, manager: Agent, scenario: Any, change_tracker: BuildingChangeTracker, groupchat: GroupChat) -> List:
    """Run a scenario through the multi-agent system."""
    # Prepare the initial message
    initial_message = f"""
    The following building data has been received:
    
    {scenario.to_prompt()}
    
    Analyze this data, identify any issues or optimization opportunities, and propose specific changes.
    
    Data Integration Agent: First analyze the overall situation and identify which specialized agents need to be consulted.
    
    Each specialized agent: Analyze the data relevant to your domain and propose specific changes using the CHANGE PROPOSAL format.
    
    Data Integration Agent: After all specialized agents have responded, review each proposed change and either approve or reject it using the CHANGE REVIEW format.
    
    Data Integration Agent: After reviewing all changes, synthesize the approved changes into a coherent action plan and final report.
    
    End your final recommendation with the text "FINAL RECOMMENDATION" to indicate completion.
    """
    
    # Start the conversation
    user_proxy.initiate_chat(manager, message=initial_message)
    
    # After the conversation is complete, process all messages to extract changes
    chat_history = process_chat_history(groupchat.messages, change_tracker)
    
    return chat_history

def process_chat_history(messages, change_tracker: BuildingChangeTracker) -> List:
    """Process the chat history to extract changes and reviews."""
    print("\nDEBUG - Starting process_chat_history...")
    
    # First pass: Extract all change proposals
    print("DEBUG - Pass 1: Extracting Proposals...")
    proposal_count = 0
    for message in messages:
        if "content" not in message or not message["content"]:
            continue
        
        content = message["content"]
        sender = message.get("name", "unknown")
        
        # Extract change proposals from specialized agents
        if sender in ["energy_optimization_agent", "predictive_maintenance_agent", "safety_compliance_agent"]:
            # Store current count before extraction
            current_count = len(change_tracker.get_all_changes())
            extract_change_proposal(content, change_tracker)
            # Check if new proposals were added
            new_count = len(change_tracker.get_all_changes())
            if new_count > current_count:
                proposal_count += (new_count - current_count)
                print(f"DEBUG - Found {new_count - current_count} proposal(s) in message from {sender}")
    
    print(f"DEBUG - Pass 1 Complete. Total proposals found: {proposal_count}")

    # Second pass: Extract all reviews
    print("\nDEBUG - Pass 2: Extracting Reviews...")
    review_count = 0
    for message in messages:
        if "content" not in message or not message["content"]:
            continue
        
        content = message["content"]
        sender = message.get("name", "unknown")
        
        # Extract change reviews from data integration agent
        if sender == "data_integration_agent":
            # Store current state before extraction
            verified_before = len(change_tracker.get_verified_changes())
            rejected_before = len(change_tracker.get_rejected_changes())
            extract_change_review(content, change_tracker)
            # Check if status changed
            verified_after = len(change_tracker.get_verified_changes())
            rejected_after = len(change_tracker.get_rejected_changes())
            if verified_after > verified_before or rejected_after > rejected_before:
                review_count += (verified_after - verified_before) + (rejected_after - rejected_before)
                print(f"DEBUG - Found review/status update in message from {sender}")
    
    print(f"DEBUG - Pass 2 Complete. Total reviews processed: {review_count}")

    # Final check for blanket approval/rejection based on final recommendation
    print("\nDEBUG - Pass 3: Final Recommendation Check...")
    final_rec_found = False
    for message in messages:
        if "content" not in message or not message["content"]:
            continue
        
        content = message["content"]
        sender = message.get("name", "unknown")
        
        if sender == "data_integration_agent" and "FINAL RECOMMENDATION" in content.upper():
            final_rec_found = True
            print("DEBUG - Found FINAL RECOMMENDATION message. Applying blanket approval for remaining pending changes.")
            pending_before = len(change_tracker.get_pending_changes())
            if pending_before > 0:
                for change in change_tracker.get_pending_changes():
                    change_tracker.update_change_status(change["id"], "verified", "Implied approval from final recommendation")
                    print(f"DEBUG - Auto-verified pending change ID {change['id']}")
                pending_after = len(change_tracker.get_pending_changes())
                print(f"DEBUG - Auto-verified {pending_before - pending_after} changes.")
            else:
                print("DEBUG - No pending changes to auto-verify.")
            break # Stop after finding the first final recommendation
    
    if not final_rec_found:
        print("DEBUG - No FINAL RECOMMENDATION message found.")
    
    # Final status check
    print("\nDEBUG - Final Change Tracker Status:")
    print(f"DEBUG - Total changes: {len(change_tracker.get_all_changes())}")
    print(f"DEBUG - Verified changes: {len(change_tracker.get_verified_changes())}")
    print(f"DEBUG - Rejected changes: {len(change_tracker.get_rejected_changes())}")
    print(f"DEBUG - Pending changes: {len(change_tracker.get_pending_changes())}")
    
    # Return the chat history for transcript generation
    return messages
