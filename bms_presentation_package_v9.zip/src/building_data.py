from pydantic import BaseModel, Field
from typing import Dict, List, Optional

class BuildingData(BaseModel):
    location: str = "Main Campus Building A"
    systems: Dict[str, Dict[str, str]] = Field(default_factory=lambda: {
        "HVAC": {"status": "Operational", "temperature": "22C", "mode": "Auto"},
        "Lighting": {"status": "Operational", "level": "80%", "zone": "Office Area"},
        "Security": {"status": "Armed", "access_points": "Locked", "alarms": "Inactive"},
        "Energy": {"status": "Monitoring", "consumption": "Normal", "source": "Grid"}
    })
    issues: List[str] = Field(default_factory=list)
    timestamp: Optional[str] = None

# Example usage:
# building_state = BuildingData()
# print(building_state.model_dump_json(indent=2))

