from .building_data import BuildingData
from datetime import datetime

def create_normal_scenario():
    """Creates a scenario with normal building conditions."""
    return BuildingData(
        timestamp=datetime.now().isoformat(),
        issues=["Routine system check required."]
    )

def create_single_issue_scenario():
    """Creates a scenario with a single issue (e.g., HVAC temperature anomaly)."""
    data = BuildingData(
        timestamp=datetime.now().isoformat(),
        issues=["HVAC reports unusual temperature fluctuations in Zone C."]
    )
    data.systems["HVAC"]["status"] = "Warning"
    data.systems["HVAC"]["temperature"] = "25C"
    return data

def create_multiple_issues_scenario():
    """Creates a scenario with multiple issues (e.g., HVAC and Security)."""
    data = BuildingData(
        timestamp=datetime.now().isoformat(),
        issues=[
            "HVAC system in Zone B is unresponsive.",
            "Security alert: Unauthorized access attempt detected at Main Entrance.",
            "Lighting levels in Conference Room 3 are below standard."
        ]
    )
    data.systems["HVAC"]["status"] = "Error"
    data.systems["HVAC"]["mode"] = "Manual Override"
    data.systems["Security"]["status"] = "Alert"
    data.systems["Security"]["alarms"] = "Active - Main Entrance"
    data.systems["Lighting"]["status"] = "Warning"
    data.systems["Lighting"]["level"] = "40%"
    return data

