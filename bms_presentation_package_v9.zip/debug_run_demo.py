#!/usr/bin/env python3
import os
import json
import argparse
import webbrowser
import time
from datetime import datetime
from fpdf import FPDF
import matplotlib.pyplot as plt
import io
import base64
import shutil # Added for copying report

# --- MODIFIED IMPORT: Use debug_agents --- 
from debug_agents import initialize_agents, run_scenario, BuildingChangeTracker, process_chat_history
# --- END MODIFIED IMPORT --- 

from src.scenarios import create_single_issue_scenario, create_multiple_issues_scenario, create_normal_scenario # Added normal scenario
from src.building_data import BuildingData # Corrected import
from rich.console import Console
from rich.panel import Panel

console = Console()

# --- Constants ---
GUI_DIR = "gui"
REPORTS_DIR = "reports"
TRANSCRIPTS_DIR = "transcripts"
STATUS_FILE = os.path.join(GUI_DIR, "status.json")
GUI_HTML_FILE = os.path.join(GUI_DIR, "index.html")

# --- GUI and Reporting Functions ---

def create_gui_files():
    """Create the necessary GUI directory and files."""
    if not os.path.exists(GUI_DIR):
        os.makedirs(GUI_DIR)
        print("Created GUI directory")
    
    # Initial status
    initial_status = {
        "status": "initializing",
        "message": "Initializing agent system...",
        "changes_proposed": 0,
        "changes_approved": 0,
        "changes_rejected": 0,
        "changes": [],
        "report_path": None, # Initialize report_path
        "transcript_path": None # Initialize transcript_path
    }
    try:
        with open(STATUS_FILE, "w") as f:
            json.dump(initial_status, f, indent=2)
        print("Created status.json file")
    except Exception as e:
        print(f"ERROR creating status.json: {e}")

    # Basic HTML structure with simplified JavaScript
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Building Management MAS</title>
        <style>
            body { font-family: sans-serif; margin: 0; background-color: #f4f7fc; color: #333; }
            .header { background-color: #005792; color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; }
            .header h1 { margin: 0; font-size: 1.8em; }
            .header span { font-size: 0.9em; }
            .container { padding: 25px; display: grid; grid-template-columns: 1fr 2fr; gap: 25px; }
            .card { background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .card h2 { margin-top: 0; color: #005792; border-bottom: 1px solid #eee; padding-bottom: 10px; }
            .status-initializing { color: #ffc107; font-weight: bold; }
            .status-analyzing { color: #ffa500; font-weight: bold; }
            .status-complete { color: #28a745; font-weight: bold; }
            .change-summary span { display: inline-block; margin-right: 15px; font-size: 1.1em; }
            .change-list { max-height: 400px; overflow-y: auto; }
            .change-item { border: 1px solid #eee; border-radius: 5px; padding: 15px; margin-bottom: 15px; }
            .change-item strong { color: #005792; }
            .change-item .status { float: right; font-weight: bold; padding: 3px 8px; border-radius: 4px; }
            .status-pending { background-color: #ffc107; color: #333; }
            .status-verified { background-color: #28a745; color: white; }
            .status-rejected { background-color: #dc3545; color: white; }
            .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #005792; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 20px auto; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            .footer { text-align: center; margin-top: 30px; color: #777; font-size: 0.9em; }
            #report-link, #transcript-link { display: none; margin-top: 15px; }
            #report-link a, #transcript-link a { color: #005792; text-decoration: none; font-weight: bold; }
            .download-links { margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Johnson Controls<br>Building Management Multi-Agent System</h1>
            <span id="timestamp"></span>
        </div>
        <div class="container">
            <div class="sidebar">
                <div class="card">
                    <h2>System Status</h2>
                    <p id="status-text"><span class="status-initializing">Initializing...</span></p>
                    <p id="status-message">Waiting for system to start.</p>
                </div>
                <div class="card change-summary">
                    <h2>Change Summary</h2>
                    <p>
                        <span id="approved-count">0 Approved</span>
                        <span id="rejected-count">0 Rejected</span>
                        <span id="pending-count">0 Pending</span>
                    </p>
                </div>
                <div class="card" id="download-container">
                    <h2>Download Files</h2>
                    <div class="download-links">
                        <p id="report-link"><a href="#" target="_blank">Download PDF Report</a></p>
                        <p id="transcript-link"><a href="#" target="_blank">Download Conversation Transcript</a></p>
                    </div>
                </div>
            </div>
            <div class="card">
                <h2>Building Changes</h2>
                <div id="change-list" class="change-list">
                    <div id="spinner" class="spinner"></div>
                    <p id="waiting-text" style="text-align: center;">Waiting for agent analysis...</p>
                </div>
            </div>
        </div>
        <div class="footer">
            Johnson Controls Building Management Multi-Agent System © 2025
        </div>

        <script>
            // Global variables
            let updateInterval = null;
            let isComplete = false;

            function updateTimestamp() {
                const now = new Date();
                const timestampEl = document.getElementById(\'timestamp\');
                if (timestampEl) timestampEl.textContent = now.toLocaleString();
            }

            function updateStatus() {
                // Only fetch if not already complete
                if (isComplete) return;
                
                fetch(\'status.json?t=\' + Date.now()) // Prevent caching
                    .then(response => {
                        if (!response.ok) {
                            throw new Error("Network response was not ok " + response.statusText);
                        }
                        return response.json();
                    })
                    .then(data => {
                        // Update Status Text
                        const statusText = document.getElementById(\'status-text\');
                        if (statusText) statusText.innerHTML = \'<span class="status-\' + data.status + \'">\' + 
                            data.status.charAt(0).toUpperCase() + data.status.slice(1) + \'</span>\';
                        const statusMessage = document.getElementById(\'status-message\');
                        if (statusMessage) statusMessage.textContent = data.message;

                        // Update Change Summary
                        const approved = data.changes_approved || 0;
                        const rejected = data.changes_rejected || 0;
                        const proposed = data.changes_proposed || 0;
                        const pending = proposed - approved - rejected;
                        const approvedCount = document.getElementById(\'approved-count\');
                        if (approvedCount) approvedCount.textContent = approved + \' Approved\';
                        const rejectedCount = document.getElementById(\'rejected-count\');
                        if (rejectedCount) rejectedCount.textContent = rejected + \' Rejected\';
                        const pendingCount = document.getElementById(\'pending-count\');
                        if (pendingCount) pendingCount.textContent = pending + \' Pending\';

                        // Update Change List
                        const changeList = document.getElementById(\'change-list\');
                        const spinner = document.getElementById(\'spinner\');
                        const waitingText = document.getElementById(\'waiting-text\');
                        
                        if (changeList && spinner && waitingText) { // Check if elements exist
                            if (data.changes && data.changes.length > 0) {
                                spinner.style.display = \'none\';
                                waitingText.style.display = \'none\';
                                changeList.innerHTML = \'\'; // Clear previous changes
                                data.changes.forEach(change => {
                                    const div = document.createElement(\'div\');
                                    div.className = \'change-item\';
                                    div.innerHTML = `
                                        <span class="status status-${change.status}">${change.status.toUpperCase()}</span>
                                        <strong>Agent:</strong> ${change.agent}<br>
                                        <strong>System:</strong> ${change.system}<br>
                                        <strong>Action:</strong> ${change.action}<br>
                                        <strong>Reason:</strong> ${change.reason}<br>
                                        <em>Proposed: ${change.timestamp}</em>
                                    `;
                                    changeList.appendChild(div);
                                });
                            } else if (data.status === \'complete\') {
                                spinner.style.display = \'none\';
                                waitingText.textContent = \'No changes were proposed or tracked.\';
                                waitingText.style.display = \'block\';
                                changeList.innerHTML = \'\'; // Clear list
                                changeList.appendChild(waitingText);
                            } else {
                                spinner.style.display = \'block\';
                                waitingText.style.display = \'block\';
                                changeList.innerHTML = \'\'; // Clear if analysis restarted
                                changeList.appendChild(spinner);
                                changeList.appendChild(waitingText);
                            }
                        }
                        
                        // Show report link if available
                        const reportLink = document.getElementById(\'report-link\');
                        if (reportLink) {
                            if (data.report_path) {
                                reportLink.style.display = \'block\';
                                const reportAnchor = reportLink.querySelector(\'a\');
                                if (reportAnchor) {
                                    reportAnchor.href = data.report_path;
                                    reportAnchor.textContent = `Download PDF Report`;
                                }
                            } else {
                                reportLink.style.display = \'none\';
                            }
                        }
                        
                        // Show transcript link if available
                        const transcriptLink = document.getElementById(\'transcript-link\');
                        if (transcriptLink) {
                            if (data.transcript_path) {
                                transcriptLink.style.display = \'block\';
                                const transcriptAnchor = transcriptLink.querySelector(\'a\');
                                if (transcriptAnchor) {
                                    transcriptAnchor.href = data.transcript_path;
                                    transcriptAnchor.textContent = `Download Conversation Transcript`;
                                }
                            } else {
                                transcriptLink.style.display = \'none\';
                            }
                        }

                         # If status is complete, stop polling and ensure UI is updated
                        if (data.status === \'complete\') {
                            console.log(\'Analysis complete detected. Forcing UI update and stopping polling.\');
                            isComplete = true; // Set flag to prevent further fetches

                            // --- Force final UI update ---
                            const statusText = document.getElementById(\'status-text\');
                            if (statusText) statusText.innerHTML = \'<span class="status-complete">Complete</span>\';
                            const statusMessage = document.getElementById(\'status-message\');
                            if (statusMessage) statusMessage.textContent = data.message;

                            const reportLink = document.getElementById(\'report-link\');
                            if (reportLink && data.report_path) {
                                reportLink.style.display = \'block\';
                                const reportAnchor = reportLink.querySelector(\'a\');
                                if (reportAnchor) reportAnchor.href = data.report_path;
                            }
                            const transcriptLink = document.getElementById(\'transcript-link\');
                            if (transcriptLink && data.transcript_path) {
                                transcriptLink.style.display = \'block\';
                                const transcriptAnchor = transcriptLink.querySelector(\'a\');
                                if (transcriptAnchor) transcriptAnchor.href = data.transcript_path;
                            }
                            // --- End Force final UI update ---

                            // Clear the interval *after* ensuring UI is updated
                            if (updateInterval) {
                                clearInterval(updateInterval);
                                updateInterval = null;
                                console.log(\'Update interval cleared.\');
                            }
                        }
                    })
                    .catch(error => {
                        console.error(\'Error fetching or processing status:\', error);
                        // Only show error if not already complete
                        if (!isComplete) {
                            // Display an error message to the user in the GUI
                            const changeList = document.getElementById(\'change-list\');
                            if (changeList) changeList.innerHTML = `<p style=\'color: red; text-align: center;\'>Error loading status. Please check console.</p>`;
                            // Safely hide spinner and waiting text
                            const spinner = document.getElementById(\'spinner\');
                            if (spinner) spinner.style.display = \'none\';
                            const waitingText = document.getElementById(\'waiting-text\');
                            if (waitingText) waitingText.style.display = \'none\';
                        }
                    });
            }

            // Initial setup
            updateTimestamp();
            setInterval(updateTimestamp, 1000); // Update time every second
            updateStatus(); // Initial status load
            updateInterval = setInterval(updateStatus, 3000); // Update status every 3 seconds
            
            // One-time check after 30 seconds to see if we should stop polling
            setTimeout(() => {
                if (!isComplete) {
                    fetch(\'status.json?t=\' + Date.now())
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === \'complete\') {
                                console.log(\'Analysis complete (delayed check), stopping updates\");
                                isComplete = true;
                                if (updateInterval) {
                                    clearInterval(updateInterval);
                                    updateInterval = null;
                                }
                            }
                        })
                        .catch(error => console.error(\'Error in delayed check:\', error));
                }
            }, 30000);
        </script>
    </body>
    </html>
    """
    try:
        with open(GUI_HTML_FILE, "w") as f:
            f.write(html_content)
        print("Created index.html file")
    except Exception as e:
        print(f"ERROR creating index.html: {e}")

def update_status_json(status: str, message: str, change_tracker: BuildingChangeTracker = None, report_filename: str = None, transcript_filename: str = None):
    """Update the status JSON file for the GUI."""
    print(f"DEBUG - Updating status.json: status={status}, message={message}")
    
    # Create GUI directory if it doesn\\'t exist
    if not os.path.exists(GUI_DIR):
        os.makedirs(GUI_DIR)
        print(f"Created GUI directory: {GUI_DIR}")
    
    data = {
        "status": status,
        "message": message,
        "changes_proposed": 0,
        "changes_approved": 0,
        "changes_rejected": 0,
        "changes": [],
        "report_path": report_filename, # Use the relative filename
        "transcript_path": transcript_filename # Add transcript path
    }
    if change_tracker:
        all_changes = change_tracker.get_all_changes()
        approved_changes = change_tracker.get_verified_changes()
        rejected_changes = change_tracker.get_rejected_changes()
        data["changes_proposed"] = len(all_changes)
        data["changes_approved"] = len(approved_changes)
        data["changes_rejected"] = len(rejected_changes)
        # Sort changes by ID for consistent display
        data["changes"] = sorted(all_changes, key=lambda x: x["id"])
        print(f"DEBUG - Writing {len(all_changes)} changes to status.json")
        
    try:
        with open(STATUS_FILE, "w") as f:
            json.dump(data, f, indent=2)
        print(f"DEBUG - Successfully wrote to {STATUS_FILE}")
    except Exception as e:
        print(f"ERROR updating status.json: {e}")

def open_gui():
    """Open the GUI HTML file in the default web browser."""
    # Use localhost URL if server is expected to be running
    url = f"http://localhost:8000/{GUI_HTML_FILE}"
    print(f"Attempting to open GUI at: {url}")
    try:
        webbrowser.open(url)
        print("Browser should be opening the GUI page.")
    except Exception as e:
        print(f"Could not open browser automatically: {e}")
        print(f"Please manually open your browser and navigate to: {url}")

class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Building Management System Analysis Report", 0, 1, "C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", 0, 0, "C")

    def chapter_title(self, title):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, title, 0, 1, "L")
        self.ln(4)

    def chapter_body(self, body):
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, body)
        self.ln()

    def add_table(self, headers, data):
        self.set_font("Arial", "B", 9)
        col_widths = [10, 40, 30, 80, 20] # Adjusted widths: ID, Agent, System, Action, Status
        # Headers
        for i, header in enumerate(headers):
            self.cell(col_widths[i], 7, header, 1, 0, "C")
        self.ln()
        # Data
        self.set_font("Arial", "", 8)
        for row in data:
            # Store Y position before starting the row
            y_before = self.get_y()
            max_h = 5 # Minimum cell height
            
            # Calculate max height needed for this row
            for i, item in enumerate(row):
                if i == 3: # Action column needs wrapping
                    lines = self.multi_cell(col_widths[i], 5, str(item), border=0, split_only=True)
                    h = len(lines) * 5
                    if h > max_h: max_h = h
                else:
                    # For other columns, check if text fits, otherwise estimate lines
                    text_w = self.get_string_width(str(item))
                    lines_needed = (text_w // col_widths[i]) + 1 if col_widths[i] > 0 else 1
                    h = lines_needed * 5
                    if h > max_h: max_h = h
            
            # Check for page break before drawing the row
            if self.get_y() + max_h > self.page_break_trigger:
                self.add_page()
                # Redraw headers on new page
                self.set_font("Arial", "B", 9)
                for i, header in enumerate(headers):
                    self.cell(col_widths[i], 7, header, 1, 0, "C")
                self.ln()
                self.set_font("Arial", "", 8)
                y_before = self.get_y() # Reset y_before for the new page

            # Draw cells with calculated max height
            x_start = self.get_x()
            for i, item in enumerate(row):
                x = self.get_x()
                # Use y_before to ensure all cells in the row start at the same Y position
                self.multi_cell(col_widths[i], max_h, str(item), border=1, align="L") 
                # Set position for the next cell in the same row, using y_before
                self.set_xy(x + col_widths[i], y_before) 
            # Move to the next line after the tallest cell
            self.set_xy(x_start, y_before + max_h)

def generate_pdf_report(scenario: BuildingData, change_tracker: BuildingChangeTracker) -> str:
    """Generate a PDF report summarizing the analysis."""
    if not os.path.exists(REPORTS_DIR):
        os.makedirs(REPORTS_DIR)
        print("Created reports directory")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"building_analysis_{timestamp}.pdf"
    filepath = os.path.join(REPORTS_DIR, filename)
    gui_filepath = os.path.join(GUI_DIR, filename) # Path for GUI access

    pdf = PDF()
    pdf.alias_nb_pages()
    pdf.add_page()

    # Building Info
    pdf.chapter_title(f"Building Location: {scenario.location}")
    pdf.chapter_body(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Changes Summary
    pdf.chapter_title("Changes Summary")
    all_changes = change_tracker.get_all_changes()
    approved_changes = change_tracker.get_verified_changes()
    rejected_changes = change_tracker.get_rejected_changes()
    pending_changes = change_tracker.get_pending_changes()
    
    pdf.chapter_body(
        f"Total Changes Proposed: {len(all_changes)}\n"
        f"Approved Changes: {len(approved_changes)}\n"
        f"Rejected Changes: {len(rejected_changes)}\n"
        f"Pending Changes: {len(pending_changes)}"
    )

    # Pie Chart
    labels = ["Approved", "Rejected", "Pending"]
    sizes = [len(approved_changes), len(rejected_changes), len(pending_changes)]
    colors = ["#28a745", "#dc3545", "#ffc107"]
    
    # Filter out zero-sized slices to avoid matplotlib errors/warnings
    filtered_labels = [l for i, l in enumerate(labels) if sizes[i] > 0]
    filtered_sizes = [s for s in sizes if s > 0]
    filtered_colors = [c for i, c in enumerate(colors) if sizes[i] > 0]
    
    if filtered_sizes: # Only generate chart if there are non-zero slices
        # Explode the largest slice slightly if desired (e.g., Approved)
        explode = tuple([0.1 if l == "Approved" else 0 for l in filtered_labels])
        
        fig, ax = plt.subplots()
        ax.pie(filtered_sizes, explode=explode, labels=filtered_labels, colors=filtered_colors, autopct='%1.1f%%', startangle=90)
        ax.axis('equal') # Equal aspect ratio ensures that pie is drawn as a circle.
        plt.title("Change Proposal Status")
        
        # Save chart to a BytesIO object
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        plt.close(fig) # Close the figure to free memory
        
        # Embed chart in PDF
        pdf.image(buf, x=pdf.w / 2 - 50, w=100) # Center the image
        pdf.ln(10)
    else:
        pdf.chapter_body("No changes to display in chart.")

    # Detailed Changes Table
    pdf.chapter_title("Detailed Changes")
    headers = ["ID", "Agent", "System", "Action", "Status"]
    table_data = []
    for change in sorted(all_changes, key=lambda x: x["id"]):
        table_data.append([
            change["id"],
            change["agent"],
            change["system"],
            change["action"],
            change["status"].upper()
        ])
    
    if table_data:
        pdf.add_table(headers, table_data)
    else:
        pdf.chapter_body("No changes were proposed or tracked.")

    # Save the PDF
    try:
        pdf.output(filepath)
        print(f"PDF report generated: {filepath}")
        # Copy the report to the GUI directory for download link
        shutil.copy(filepath, gui_filepath)
        print(f"Copied report to GUI directory: {gui_filepath}")
        return filename # Return only the filename for relative linking
    except Exception as e:
        print(f"ERROR generating PDF report: {e}")
        return None

def generate_transcript_pdf(chat_history: list, filename_prefix="conversation_transcript") -> str:
    """Generate a PDF transcript of the agent conversation."""
    if not os.path.exists(TRANSCRIPTS_DIR):
        os.makedirs(TRANSCRIPTS_DIR)
        print("Created transcripts directory")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{filename_prefix}_{timestamp}.pdf"
    filepath = os.path.join(TRANSCRIPTS_DIR, filename)
    gui_filepath = os.path.join(GUI_DIR, filename) # Path for GUI access

    pdf = PDF()
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_font("Arial", "", 10)
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Agent Conversation Transcript", 0, 1, "C")
    pdf.ln(10)

    for message in chat_history:
        sender = message.get("name", "Unknown Agent")
        content = message.get("content", "")
        role = message.get("role", "assistant") # Default to assistant
        
        # Clean up sender name
        sender_display = sender.replace("_agent", "").replace("_", " ").title()
        if sender == "user_proxy":
            sender_display = "Building Manager (User Proxy)"
        
        pdf.set_font("Arial", "B", 11)
        pdf.cell(0, 7, f"{sender_display} ({role.title()}):", 0, 1)
        
        pdf.set_font("Arial", "", 10)
        # Use multi_cell for the content to allow wrapping
        pdf.multi_cell(0, 5, content)
        pdf.ln(5) # Add some space between messages

    try:
        pdf.output(filepath)
        print(f"PDF transcript generated: {filepath}")
        # Copy the transcript to the GUI directory
        shutil.copy(filepath, gui_filepath)
        print(f"Copied transcript to GUI directory: {gui_filepath}")
        return filename # Return only the filename
    except Exception as e:
        print(f"ERROR generating PDF transcript: {e}")
        return None

# --- Main Execution ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the Building Management Multi-Agent System Demo.")
    parser.add_argument("--scenario", type=str, default="multiple", choices=["single", "multiple", "normal"], help="Scenario type to run (single issue, multiple issues, normal operation)")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output.")
    parser.add_argument("--no-gui", action="store_true", help="Run without opening the GUI.")
    args = parser.parse_args()

    console.print(Panel("Starting Building Management Multi-Agent System Demo", title="Initialization", style="bold blue"))

    # Create GUI files and initial status
    create_gui_files()
    update_status_json("initializing", "Initializing agent system...")

    # Open GUI in browser unless --no-gui is specified
    if not args.no_gui:
        # Give the server a moment to start if running separately
        print("Waiting a moment before opening browser...")
        time.sleep(2)
        open_gui()

    # Initialize agents
    console.print("Initializing agents...", style="cyan")
    user_proxy, manager, change_tracker, groupchat = initialize_agents(verbose=args.verbose)
    update_status_json("initializing", "Agents initialized.", change_tracker)

    # Select and create scenario
    console.print(f"Creating scenario: {args.scenario}...", style="cyan")
    if args.scenario == "single":
        scenario = create_single_issue_scenario()
    elif args.scenario == "multiple":
        scenario = create_multiple_issues_scenario()
    else: # normal
        scenario = create_normal_scenario()
    update_status_json("analyzing", f"Running scenario: {args.scenario}...", change_tracker)

    # Run the scenario
    console.print(Panel(f"Running Scenario: {args.scenario.capitalize()} Issues", title="Agent Conversation", style="bold green"))
    start_time = time.time()
    # --- Skip live agent conversation for hardcoded demo ---
    # chat_history = run_scenario(user_proxy, manager, scenario, change_tracker, groupchat)
    chat_history = [] # Assign empty list as placeholder
    console.print("Skipping live agent conversation for hardcoded demo.", style="bold yellow")
    # --- End skip ---

    end_time = time.time()
    console.print(f"Scenario completed in {end_time - start_time:.2f} seconds.", style="bold green")

    # Generate PDF Report
    console.print("Generating PDF report...", style="cyan")
    report_filename = generate_pdf_report(scenario, change_tracker)
    
    # Generate PDF Transcript
    console.print("Generating PDF transcript...", style="cyan")
    transcript_filename = generate_transcript_pdf(chat_history)

    # Final status update
    update_status_json("complete", "Analysis complete! Report generated.", change_tracker, report_filename, transcript_filename)
    
    # Add a small delay to ensure the GUI has time to fetch the final status
    print("Waiting for GUI to update...")
    time.sleep(5) 


    # Rewrite HTML with final static state
    rewrite_final_html(report_filename, transcript_filename, change_tracker)

    # Print final summary to console
    console.print(Panel("Analysis Complete", title="Summary", style="bold blue"))
    console.print(f"Building Location: {scenario.location}")
    console.print(f"Total Changes Proposed: {len(change_tracker.get_all_changes())}")
    console.print(f"Approved Changes: {len(change_tracker.get_verified_changes())}")
    console.print(f"Rejected Changes: {len(change_tracker.get_rejected_changes())}")
    console.print(f"Pending Changes: {len(change_tracker.get_pending_changes())}")
    if report_filename:
        console.print(f"PDF Report: {os.path.join(REPORTS_DIR, report_filename)}")
    if transcript_filename:
        console.print(f"PDF Transcript: {os.path.join(TRANSCRIPTS_DIR, transcript_filename)}")
    
    console.print("\nDemo finished. You can view the results in the GUI (if opened) or the generated PDF files.", style="bold blue")
    console.print("If running with a local server, keep it running to view the GUI.", style="yellow")



def rewrite_final_html(report_filename: str, transcript_filename: str, change_tracker: BuildingChangeTracker):
    """Rewrite the index.html file with the final static state after the script completes."""
    print("Rewriting index.html with final static state...")

    # Fetch final change data
    all_changes = change_tracker.get_all_changes()
    approved_changes = change_tracker.get_verified_changes()
    rejected_changes = change_tracker.get_rejected_changes()
    pending_changes = len(all_changes) - len(approved_changes) - len(rejected_changes)

    # Build static change list HTML
    change_list_html = ""
    if all_changes:
        for change in sorted(all_changes, key=lambda x: x["id"]):
            change_list_html += f'''
            <div class="change-item">
                <span class="status status-{change["status"]}">{change["status"].upper()}</span>
                <strong>Agent:</strong> {change["agent"]}<br>
                <strong>System:</strong> {change["system"]}<br>
                <strong>Action:</strong> {change["action"]}<br>
                <strong>Reason:</strong> {change["reason"]}<br>
                <em>Proposed: {change["timestamp"]}</em>
            </div>
            '''
    else:
        change_list_html = '<p style="text-align: center;">No changes were proposed or tracked.</p>' # Corrected line

    # Build download links HTML
    report_link_html = ""
    if report_filename:
        report_link_html = f'<p id="report-link"><a href="{report_filename}" target="_blank">Download PDF Report</a></p>'
    else:
        report_link_html = '<p id="report-link" style="display: none;"><a href="#" target="_blank">Download PDF Report</a></p>'

    transcript_link_html = ""
    if transcript_filename:
        transcript_link_html = f'<p id="transcript-link"><a href="{transcript_filename}" target="_blank">Download Conversation Transcript</a></p>'
    else:
        transcript_link_html = '<p id="transcript-link" style="display: none;"><a href="#" target="_blank">Download Conversation Transcript</a></p>'

    # Construct the final static HTML content with cache control
    final_html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv='cache-control' content='no-cache, no-store, must-revalidate'>
    <meta http-equiv='pragma' content='no-cache'>
    <meta http-equiv='expires' content='0'>
    <title>Building Management MAS</title>
    <style>
        body {{ font-family: sans-serif; margin: 0; background-color: #f4f4f4; color: #333; }}
        .header {{ background-color: #005f9e; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }}
        .header h1 {{ margin: 0; font-size: 1.5em; }}
        .timestamp {{ font-size: 0.9em; }}
        .container {{ display: flex; padding: 20px; gap: 20px; flex-wrap: wrap; }}
        .sidebar {{ flex: 1; min-width: 250px; }}
        .main-content {{ flex: 3; min-width: 400px; }}
        .card {{ background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }}
        .card h2 {{ margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; font-size: 1.2em; color: #005f9e; }}
        .status-initializing {{ color: #ffc107; font-weight: bold; }}
        .status-analyzing {{ color: #fd7e14; font-weight: bold; }}
        .status-complete {{ color: #28a745; font-weight: bold; }}
        .change-summary span {{ display: inline-block; margin-right: 15px; font-size: 0.95em; }}
        .change-list {{ max-height: 500px; overflow-y: auto; }}
        .change-item {{ border: 1px solid #eee; border-radius: 4px; padding: 15px; margin-bottom: 10px; position: relative; background-color: #fdfdfd; }}
        .change-item strong {{ color: #555; }}
        .change-item em {{ font-size: 0.85em; color: #777; }}
        .change-item .status {{ position: absolute; top: 10px; right: 10px; padding: 3px 8px; border-radius: 12px; font-size: 0.8em; font-weight: bold; color: white; }}
        .status-verified {{ background-color: #28a745; }}
        .status-rejected {{ background-color: #dc3545; }}
        .status-pending {{ background-color: #ffc107; color: #333 !important; }}
        .download-links p {{ margin: 5px 0; }}
        .download-links a {{ color: #005f9e; text-decoration: none; }}
        .download-links a:hover {{ text-decoration: underline; }}
        .footer {{ background-color: #e9ecef; text-align: center; padding: 10px; font-size: 0.85em; color: #6c757d; margin-top: 20px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Johnson Controls<br>Building Management Multi-Agent System</h1>
        <div id="timestamp" class="timestamp">{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</div>
    </div>
    <div class="container">
        <div class="sidebar">
            <div class="card">
                <h2>System Status</h2>
                <p id="status-text"><span class="status-complete">Complete</span></p>
                <p id="status-message">Analysis complete! Report generated.</p>
            </div>
            <div class="card">
                <h2>Change Summary</h2>
                <div class="change-summary">
                    <span id="approved-count">{len(approved_changes)} Approved</span>
                    <span id="rejected-count">{len(rejected_changes)} Rejected</span>
                    <span id="pending-count">{pending_changes} Pending</span>
                </div>
            </div>
            <div class="card" id="download-container">
                <h2>Download Files</h2>
                <div class="download-links">
                    {report_link_html}
                    {transcript_link_html}
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="card">
                <h2>Building Changes</h2>
                <div id="change-list" class="change-list">
                    {change_list_html}
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        Johnson Controls Building Management Multi-Agent System © 2025
    </div>
    <script>
        // Minimal script just for timestamp update
        function updateTimestamp() {{
            const now = new Date();
            const timestampEl = document.getElementById('timestamp');
            if (timestampEl) timestampEl.textContent = now.toLocaleString();
        }}
        updateTimestamp();
        setInterval(updateTimestamp, 1000);
    </script>
</body>
</html>
"""

    try:
        with open(GUI_HTML_FILE, "w") as f:
            f.write(final_html_content)
        print(f"[SUCCESS] Successfully rewrote {GUI_HTML_FILE} with final static state.") # Added success confirmation
    except Exception as e:
        print(f"[ERROR] Failed rewriting final index.html: {e}") # Enhanced error logging

# --- Modify Main Execution ---
# Add the call to rewrite_final_html at the very end


