# Building Management Multi-Agent System - Presentation Guide (v4)

This guide provides instructions for setting up and running the Building Management Multi-Agent System demonstration for your May 5th presentation. This version uses **hardcoded changes** in `debug_agents.py` to ensure a reliable visual demonstration in the GUI and PDF report.

**IMPORTANT:** Run all commands from the **new directory** where you extract this package.

## Prerequisites

*   **Python 3:** Ensure you have Python 3 installed (preferably 3.8 or higher).
*   **pip:** Python's package installer.
*   **OpenAI API Key:** You need an API key from OpenAI.

## Setup Instructions

1.  **Create a New Directory:** Create a completely new, empty folder for this demonstration. Let's call it `BMS_Demo`.
    ```bash
    mkdir BMS_Demo
    cd BMS_Demo
    ```

2.  **Extract the Package:** Download the `bms_presentation_package_v4.zip` file and extract its contents directly into the `BMS_Demo` folder.
    *   On macOS, you can usually double-click the zip file, or use:
        ```bash
        unzip /path/to/bms_presentation_package_v4.zip
        ```
    *   Your `BMS_Demo` folder should now contain `debug_run_demo.py`, `debug_agents.py`, `requirements.txt`, `.env.example`, and the `src`, `gui`, and `config` directories.

3.  **Create `.env` File:** Create a file named `.env` in the `BMS_Demo` folder and add your OpenAI API key:
    ```bash
    echo "OPENAI_API_KEY=your_actual_openai_api_key_here" > .env
    ```
    Replace `your_actual_openai_api_key_here` with your real key.

4.  **Install Dependencies:** Open your terminal, navigate **into the `BMS_Demo` folder**, and install the required Python packages:
    ```bash
    cd /path/to/your/BMS_Demo
    pip3 install -r requirements.txt
    ```
    *(Note: If you encounter permission issues, you might need to use `pip3 install --user -r requirements.txt`)*

## Running the Demonstration (Two-Terminal Method - Recommended)

This method uses two separate terminal windows, making it clear what's happening.

1.  **Terminal 1: Start the Web Server**
    *   Open a terminal window.
    *   Navigate **into the `BMS_Demo` directory**:
        ```bash
        cd /path/to/your/BMS_Demo
        ```
    *   Start Python's built-in HTTP server:
        ```bash
        python3 -m http.server
        ```
    *   You should see a message like `Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...`.
    *   **Leave this terminal running.** It serves the GUI files to your browser.

2.  **Terminal 2: Run the Agent System**
    *   Open a **second, new** terminal window.
    *   Navigate **into the same `BMS_Demo` directory**:
        ```bash
        cd /path/to/your/BMS_Demo
        ```
    *   Run the demonstration script using the `debug_run_demo.py` file:
        ```bash
        python3 debug_run_demo.py --verbose
        ```
    *   The script will start, initialize agents, run the scenario (using hardcoded changes), generate the transcript, generate the PDF report, and update the `gui/status.json` file.

3.  **Browser: Access the GUI**
    *   Open your web browser (Chrome, Firefox, Safari, Edge).
    *   Navigate to the following URL:
        ```
        http://localhost:8000/gui/index.html
        ```
    *   The GUI should load. Initially, it will show "Initializing..." or "Analyzing...".
    *   As the script in Terminal 2 progresses (it might take a minute or two depending on API response times), the GUI will update automatically:
        *   The status will change to "Complete".
        *   The change summary will show the hardcoded counts (6 Approved, 1 Rejected).
        *   The "Building Changes" list will populate with the 7 hardcoded changes and their statuses.
        *   Links to download the PDF report and the conversation transcript will appear.

## Expected Outcome

*   **Terminal 1:** Continues running the web server.
*   **Terminal 2:** Shows debug output from the agents, processing steps, and finally indicates completion, mentioning the generated report and transcript filenames.
*   **Browser GUI (`http://localhost:8000/gui/index.html`):**
    *   Displays "Complete" status.
    *   Shows Change Summary: 6 Approved, 1 Rejected, 0 Pending.
    *   Lists 7 changes with their details and statuses (Verified/Rejected).
    *   Provides working download links for the PDF report (in the `reports/` directory) and the transcript (in the `transcripts/` directory).
*   **Filesystem:**
    *   A PDF report file is created in the `BMS_Demo/reports/` directory.
    *   A text transcript file is created in the `BMS_Demo/transcripts/` directory.
    *   The `BMS_Demo/gui/status.json` file is updated with the final status and change details.

## Presentation Tips

*   Have the two terminals and the browser window arranged clearly on your screen.
*   Start Terminal 1 (web server) first.
*   Start Terminal 2 (agent script) and explain that the agents are now analyzing the building status.
*   Switch to the browser and show the GUI updating from "Analyzing" to "Complete".
*   Walk through the GUI: explain the status, the change summary, and the list of proposed changes with their final statuses.
*   Click the download links to show the generated PDF report and the conversation transcript.
*   Explain that this version uses predefined changes for demonstration reliability, but the core concept involves agents dynamically proposing and reviewing changes based on real-time data.

## Troubleshooting

*   **`Address already in use` Error (Terminal 1):** Another process is using port 8000. Stop the other process or try a different port: `python3 -m http.server 8080` (and access the GUI at `http://localhost:8080/gui/index.html`).
*   **`ModuleNotFoundError`:** Ensure you ran `pip3 install -r requirements.txt` from *within* the `BMS_Demo` directory.
*   **GUI shows "Error loading status":**
    *   Make sure the web server (Terminal 1) is running.
    *   Make sure you are accessing `http://localhost:8000/gui/index.html` (not a `file:///...` path).
    *   Check the browser's developer console (Right-click -> Inspect -> Console) for specific errors.
*   **Missing API Key Error:** Ensure the `.env` file exists in the `BMS_Demo` directory and contains your correct OpenAI API key.

Good luck with your presentation!
